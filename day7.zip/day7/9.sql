SELECT JOB_ID,
       COUNT(*) AS "Number of Employees"
FROM EMP
GROUP BY JOB_ID;